
package util;

import javax.swing.JOptionPane;

public class Bienvenida {
    public static void mostrarMensaje() {
        JOptionPane.showMessageDialog(null, "Bienvenido al Sistema Avícola 🐔", "Bienvenida", JOptionPane.INFORMATION_MESSAGE);
    }
}
